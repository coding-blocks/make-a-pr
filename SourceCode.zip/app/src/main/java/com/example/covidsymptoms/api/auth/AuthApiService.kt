package com.example.covidsymptoms.api.auth

import androidx.lifecycle.LiveData
import com.example.covidsymptoms.api.auth.responses.SignInResponse
import com.example.covidsymptoms.api.auth.responses.RegistrationResponse
import com.example.covidsymptoms.models.RegistrationObj
import com.example.covidsymptoms.util.GenericApiResponse
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST

interface AuthApiService {

    @GET("signin")
    fun signIn(
        @Header("androidid") androidID : String,
        @Header("date") date : String
    ) : LiveData<GenericApiResponse<SignInResponse>>

    @POST("register")
    fun register(
        @Header("date") date : String,
        @Header("Content-Type") type : String,
        @Body registrationObj: RegistrationObj
    ) : LiveData<GenericApiResponse<RegistrationResponse>>

}