package com.example.covidsymptoms.api.auth.responses

import com.example.covidsymptoms.models.EmpDetail
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class RegistrationResponse(

    @SerializedName("code")
    @Expose
    var code: Int,

    @SerializedName("description")
    @Expose
    var description: String,

    @SerializedName("empdetails")
    @Expose
    var empDetails : EmpDetail,

    @SerializedName("announcement")
    var announcement: String
)
{
    override fun toString(): String {
        return "RegistrationResponse(code=$code, description='$description', empDetails=$empDetails, announcement='$announcement')"
    }
}
