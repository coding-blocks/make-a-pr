package com.example.covidsymptoms.api.auth.responses

import com.example.covidsymptoms.models.EmpDetail
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


class SignInResponse(

    @SerializedName("code")
    @Expose
    var code: Int,

    @SerializedName("description")
    @Expose
    var description: String,

    @SerializedName("healthstatus")
    @Expose
    var healthStatus: String,

    @SerializedName("empdetails")
    @Expose
    var empDetails: EmpDetail,

    @SerializedName("announcement")
    @Expose
    var announcement: String
){
    override fun toString(): String {
        return "SignInResponse(code=$code, description='$description', healthStatus='$healthStatus', empDetails=$empDetails, announcement='$announcement')"
    }
}


