package com.example.covidsymptoms.api.main

import androidx.lifecycle.LiveData
import com.example.covidsymptoms.api.main.responses.DeleteRecordResponse
import com.example.covidsymptoms.api.main.responses.QuestionnaireResponse
import com.example.covidsymptoms.api.main.responses.UpdationResponse
import com.example.covidsymptoms.ui.DataState
import com.example.covidsymptoms.util.GenericApiResponse
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST

interface MainApiService {

    @GET("getquestionaire")
    fun getQuestionnaireFromServer(
        @Header("androidid") androidID : String,
        @Header("date") date : String
    )   : LiveData<GenericApiResponse<QuestionnaireResponse>>

    @POST("updatequestionaire")
    fun updateQuestionnaireDb(
        @Header("Content-Type") type : String,
        @Header("androidid") androidID : String,
        @Header("date") date : String,
        @Body questionnaireResponseToSend: QuestionnaireResponse
    ) : LiveData<GenericApiResponse<UpdationResponse>>

    @GET("resetuser")
    fun deleteRecordDb(
        @Header("empID") empID : Int
    ) : LiveData<GenericApiResponse<DeleteRecordResponse>>
}