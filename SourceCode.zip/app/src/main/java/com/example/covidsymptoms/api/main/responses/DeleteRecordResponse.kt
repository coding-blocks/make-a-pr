package com.example.covidsymptoms.api.main.responses

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class DeleteRecordResponse (

    @SerializedName("empid")
    @Expose
    var empID: Int,

    @SerializedName("name")
    @Expose
    var name: String,


    @SerializedName("code")
    @Expose
    var code: Int,

    @SerializedName("description")
    @Expose
    var description: String
){
    override fun toString(): String {
        return "DeleteRecordResponse(empID=$empID, name='$name', code=$code, description='$description')"
    }
}