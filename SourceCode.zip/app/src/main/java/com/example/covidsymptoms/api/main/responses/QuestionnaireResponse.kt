package com.example.covidsymptoms.api.main.responses

import com.example.covidsymptoms.models.Question
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class QuestionnaireResponse(

    @SerializedName("healthstatus")
    @Expose
    var healthStatus : String,

    @SerializedName("questions")
    @Expose
    var questions : List<Question>?

){
    override fun toString(): String {
        return "QuestionnaireResponse(healthStatus='$healthStatus', questions=$questions)"
    }
}