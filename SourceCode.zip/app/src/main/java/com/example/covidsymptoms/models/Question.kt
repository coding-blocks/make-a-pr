package com.example.covidsymptoms.models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


data class Question(

    @SerializedName("viewtype")
    @Expose
    var viewType : Int,

    @SerializedName("questionstr")
    @Expose
    var questionStr: String,

    @SerializedName("editboxans")
    @Expose
    var editboxAns: String,

    @SerializedName("checkboxans")
    @Expose
    var checkboxAns : Boolean,

    @SerializedName("haschildren")
    @Expose
    var hasChildren: Boolean,

    @SerializedName("children")
    @Expose
    var children: List<Question>,

    @SerializedName("spinstr")
    @Expose
    var spinnerStr: List<String>,

    @SerializedName("selectedvalue")
    @Expose
    var selected_val: Int,

    @SerializedName("impactonstatus")
    @Expose
    var impactOnStatus : String

){
    override fun toString(): String {
        return "Question(viewType=$viewType, questionStr='$questionStr', editboxAns='$editboxAns', checkboxAns=$checkboxAns, hasChildren=$hasChildren, children=$children, spinnerStr=$spinnerStr, selected_val='$selected_val', impactOnStatus='$impactOnStatus')"
    }
}