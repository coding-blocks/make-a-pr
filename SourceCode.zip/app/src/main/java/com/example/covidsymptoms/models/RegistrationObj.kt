package com.example.covidsymptoms.models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class RegistrationObj(
    @SerializedName("empid")
    @Expose
    var empID : Int,

    @SerializedName("orgname")
    @Expose
    var orgName : String,

    @SerializedName("androidid")
    @Expose
    var androidID : String

){
    override fun toString(): String {
        return "RegistrationObj(empID=$empID, orgName='$orgName', androidID='$androidID')"
    }
}