package com.example.covidsymptoms.repository

import android.util.Log
import androidx.lifecycle.LiveData
import com.example.covidsymptoms.api.RetrofitBuilder
import com.example.covidsymptoms.api.auth.responses.SignInResponse
import com.example.covidsymptoms.api.auth.responses.RegistrationResponse
import com.example.covidsymptoms.models.EmpDetail
import com.example.covidsymptoms.models.RegistrationObj
import com.example.covidsymptoms.ui.Data
import com.example.covidsymptoms.ui.DataState
import com.example.covidsymptoms.ui.Response
import com.example.covidsymptoms.ui.ResponseType
import com.example.covidsymptoms.ui.auth.state.AuthViewState
import com.example.covidsymptoms.ui.auth.state.RegistrationFields
import com.example.covidsymptoms.util.ApiSuccessResponse
import com.example.covidsymptoms.util.Constants
import com.example.covidsymptoms.util.Constants.Companion.REG_102
import com.example.covidsymptoms.util.GenericApiResponse
import kotlinx.coroutines.Job

object AuthRepository{

    private val TAG = "AuthRepository"

    var androidID:String? =""
    var date : String? = ""

    private var repositoryJob: Job? = null

    fun attemptSignIn(
      androidID : String,
      currentDate: String
    ): LiveData<DataState<AuthViewState>> {

        return object : NetworkBoundResource<SignInResponse,AuthViewState>(){
            override fun createCall(): LiveData<GenericApiResponse<SignInResponse>> {
                return RetrofitBuilder.authApiService.signIn(androidID,currentDate)
            }

            override suspend fun handleApiSuccessResponse(response: ApiSuccessResponse<SignInResponse>) {
                Log.d(TAG, "handleApiSuccessResponse: ${response}")

                when(response.body.code){
                    101 -> {
                        onCompleteJob(DataState.data(
                                data = AuthViewState(null,response.body.healthStatus,response.body.empDetails) ,
                                response = Response(response.body.description,ResponseType.None())
                         ))
                    }
                    102 -> {
                        onCompleteJob(DataState.data(
                            data = AuthViewState(null,"signin102",response.body.empDetails,response.body.announcement),
                            response = Response(response.body.description,ResponseType.None())
                        ))
                    }
                    103 -> {
                        onCompleteJob(DataState.data(
                            data= null,
                            response = Response(response.body.description,ResponseType.None())
                        ))
                    }

                    else -> {
                        //show error here
                    }
                }
            }

            override fun setJob(job: Job) {
                Log.d(TAG, "resetting repository job")
                repositoryJob?.cancel()
                repositoryJob = job
            }

        }.asLiveData()
    }

    fun attemptRegistration(
        employeeID: String,
        org : String,
        androidID: String
    ) : LiveData<DataState<AuthViewState>>{

        return object : NetworkBoundResource<RegistrationResponse,AuthViewState>(){
            override fun createCall(): LiveData<GenericApiResponse<RegistrationResponse>> {
                return RetrofitBuilder.authApiService.register( date!!,"application/json",
                    RegistrationObj(
                        employeeID.toInt(),
                        org,
                        androidID
                    )
                )
            }

            override suspend fun handleApiSuccessResponse(response: ApiSuccessResponse<RegistrationResponse>) {
                Log.e("AuthRepository","handleApiSuccessResponse - response = $response")
                when(response.body.code){
                    101 -> {
                        onCompleteJob(DataState.data(
                            data = AuthViewState(
                                null,"register101",response.body.empDetails,response.body.announcement
                            ),
                            response = null
                        ))
                    }
                    102 -> {
                        onCompleteJob(DataState.error(
                            Response(response.body.description,ResponseType.Dialog())
                        ))

                    }

                    104 -> {
                        onCompleteJob(DataState.error(
                            Response(response.body.description,ResponseType.Dialog())
                        ))
                    }

                    else -> {
                        onCompleteJob(DataState.error(
                            Response(response.body.description,ResponseType.Dialog())
                        ))
                    }
                }
            }

            override fun setJob(job: Job) {
                Log.d(TAG, "resetting repository job")
                repositoryJob?.cancel()
                repositoryJob = job
            }

        }.asLiveData()
    }

    //Use this if error in some fields BEFORE JOB to be started (no onComplete JOb in this)
    //Like checking if registration fields are right

    //When refactoring code use NBR defined method onErrorReturn() instead of  OnCompleteJob(DataState.error())
    private fun returnErrorResponse(errorMessage: String, responseType: ResponseType): LiveData<DataState<AuthViewState>>{
        Log.e("AuthRepository", "returnErrorResponse: ${errorMessage}")

        return object: LiveData<DataState<AuthViewState>>(){
            override fun onActive() {
                super.onActive()
                value = DataState.error(
                    Response(
                        errorMessage,
                        responseType
                    )
                )
            }
        }
    }

    fun cancelActiveJobs(){
        Log.d(TAG, "AuthRepository: Cancelling on-going jobs...")
        repositoryJob?.cancel()
    }
}