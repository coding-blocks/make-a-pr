package com.example.covidsymptoms.repository

import android.util.Log
import androidx.lifecycle.LiveData
import com.example.covidsymptoms.api.RetrofitBuilder
import com.example.covidsymptoms.api.main.MainApiService
import com.example.covidsymptoms.api.main.responses.DeleteRecordResponse
import com.example.covidsymptoms.api.main.responses.QuestionnaireResponse
import com.example.covidsymptoms.api.main.responses.UpdationResponse
import com.example.covidsymptoms.models.Question
import com.example.covidsymptoms.ui.DataState
import com.example.covidsymptoms.ui.Response
import com.example.covidsymptoms.ui.ResponseType
import com.example.covidsymptoms.ui.main.state.MainViewState
import com.example.covidsymptoms.ui.main.state.UpdationFields
import com.example.covidsymptoms.util.ApiSuccessResponse
import com.example.covidsymptoms.util.Constants
import com.example.covidsymptoms.util.GenericApiResponse
import com.example.covidsymptoms.util.testArrayListOfQuestions
import kotlinx.coroutines.Job

object MainRepository {

    private val TAG = "MainRepository"

    private var repositoryJob: Job? = null


    fun updateServerDb(
        androidID: String,
        date: String,
        healthStatus  : String,
        questionsList : List<Question>
    ) : LiveData<DataState<MainViewState>>{

        return object : NetworkBoundResource<UpdationResponse,MainViewState>(){
            override fun createCall(): LiveData<GenericApiResponse<UpdationResponse>> {
                return RetrofitBuilder.mainApiService.updateQuestionnaireDb("application/json",
                    androidID,
                    date,
                    QuestionnaireResponse(
                        healthStatus = healthStatus,
                        questions = questionsList
                    )
                )
            }

            override suspend fun handleApiSuccessResponse(response: ApiSuccessResponse<UpdationResponse>) {
                Log.e("MainRepository","handleApiSuccessResponse - response = $response")
                when(response.body.code){
                    101 -> {
                        onCompleteJob(DataState.data(
                            data = null,
                            response = Response(response.body.description, ResponseType.None())
                        ))
                    }
                    102 -> {
                        onCompleteJob(DataState.error(
                            Response(response.body.description,ResponseType.Dialog())
                        ))
                    }

                    else -> {
                        //some different error here
                    }
                }
            }

            override fun setJob(job: Job) {
                Log.e("MainRepository","setJob - $job")
                repositoryJob?.cancel()
                repositoryJob = job
            }

        }.asLiveData()
    }

    fun getQuestionnaireFromServer(
        androidID: String,
        date : String
    ): LiveData<DataState<MainViewState>>{

        return object : NetworkBoundResource<QuestionnaireResponse,MainViewState>(){
            override fun createCall(): LiveData<GenericApiResponse<QuestionnaireResponse>> {
                return RetrofitBuilder.mainApiService.getQuestionnaireFromServer(
                    androidID,
                    date
                )
            }

            override suspend fun handleApiSuccessResponse(response: ApiSuccessResponse<QuestionnaireResponse>) {
                Log.e("MainRepository","handleApiSuccessResponse - response = $response")
                if(response.body.questions == null ){
                    onCompleteJob(DataState.data(null,Response(Constants.QUESLIST_FAIL,ResponseType.None())))
                    return
                }
                response.body.questions.let {
                  Log.e("MainRepository","questionsListReceivedFromServer - $it")
                  onCompleteJob(DataState.data(
                      MainViewState(UpdationFields(
                          response.body.questions!!,
                          ""
                      )),Response(Constants.QUESLIST_OK,ResponseType.None())
                  ))
                }
                Log.e("MainRepository","Questions list received is  - ${response.body.questions}")
                //some error here
            }

            override fun setJob(job: Job) {
                repositoryJob?.cancel()
                repositoryJob = job
            }

        }.asLiveData()
    }


    //testing purposes

    fun deleteRecordInServer(
        empID: Int
    ): LiveData<DataState<MainViewState>> {
            return object : NetworkBoundResource < DeleteRecordResponse , MainViewState> (){
                override fun createCall(): LiveData<GenericApiResponse<DeleteRecordResponse>> {
                    return RetrofitBuilder.mainApiService.deleteRecordDb(empID)
                }

                override suspend fun handleApiSuccessResponse(response: ApiSuccessResponse<DeleteRecordResponse>) {
                    Log.e("MainRepository","handleApiSuccessResponse - response = $response")

                    onCompleteJob(DataState.data(null,Response(response.body.description,ResponseType.Toast())))

                }

                override fun setJob(job: Job) {
                    repositoryJob?.cancel()
                    repositoryJob = job
                }

            }.asLiveData()
    }

    private fun returnErrorResponse(errorMessage: String, responseType: ResponseType): LiveData<DataState<MainViewState>>{
        Log.d(TAG, "returnErrorResponse: ${errorMessage}")

        return object: LiveData<DataState<MainViewState>>(){
            override fun onActive() {
                super.onActive()
                value = DataState.error(
                    Response(
                        errorMessage,
                        responseType
                    )
                )
            }
        }
    }

    fun cancelActiveJobs(){
        Log.d(TAG, "MainRepository: Cancelling on-going jobs...")
        repositoryJob?.cancel()
    }

}