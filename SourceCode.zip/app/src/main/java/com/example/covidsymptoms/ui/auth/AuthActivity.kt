package com.example.covidsymptoms.ui.auth

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.provider.Settings
import android.util.Log
import android.view.View
import androidx.activity.viewModels
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Observer
import androidx.navigation.NavController
import androidx.navigation.NavDestination
import androidx.navigation.findNavController
import com.example.covidsymptoms.R
import com.example.covidsymptoms.models.EmpDetail
import com.example.covidsymptoms.repository.AuthRepository
import com.example.covidsymptoms.ui.BaseActivity
import com.example.covidsymptoms.ui.auth.state.AuthStateEvent
import com.example.covidsymptoms.ui.main.MainActivity
import com.example.covidsymptoms.util.Constants
import com.example.covidsymptoms.util.DateUtils
import kotlinx.android.synthetic.main.activity_auth.*

class AuthActivity : BaseActivity(), NavController.OnDestinationChangedListener {

    lateinit var androidID: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_auth)

         androidID = Settings.Secure.getString(
             contentResolver,
             Settings.Secure.ANDROID_ID
         )

      //  testing purposes
      // androidID = "asdfaasdasddfvasdqw3ed"

        Log.e(TAG, "android id is - $androidID")

        val viewModel: AuthViewModel by viewModels()
        Log.e(TAG, "Viewmodel - ${viewModel.hashCode()}")


        //Saving androidId in AuthRepository now , later MainActivity will also use <- can be refactored
        viewModel.updateIdAndDate(androidID, DateUtils.getCurrentDate())
        AuthRepository.androidID = androidID
        AuthRepository.date = DateUtils.getCurrentDate()

        Log.e(TAG, "AndroidID - ${viewModel.androidID}")
        Log.e(TAG, "Date - ${viewModel.date}")

        //firing event for signIn
        viewModel.setStateEvent(
            AuthStateEvent.SignInAttemptEvent(
                viewModel.androidID!!,
                viewModel.date!!
            )
        )

        findNavController(R.id.auth_nav_host_fragment).addOnDestinationChangedListener(this)
        subscribeObservers()
    }

    private fun subscribeObservers() {
        val vm: AuthViewModel by viewModels()

        //Cases - >
        /* 1) 1st time opens app  -> a                          SignIn_103
        *  2) alr signed in and filled ques today -> b          SignIn_101
        *  3) alr signed in but questions expired ->   c        SignIn_102
        *
        * after knowing that i do have to register
        *  1)  registration successful ->  d                    Register_101
        *  2)  registration failed -> e                         Register_102
        * */

        //This wasnt how  SignIn_102 and  Register_101 was to be handled at first .. can be refactored later

        vm.dataState.observe(this, Observer { dataState ->
            onDataStateChange(dataState)            //handling of any DataState.error() and DataState.data's response part done in BaseActivity
            dataState.data?.let { data ->
                data.data?.let { event ->
                    event.getContentIfNotHandled()?.let {
                        when (it.healthStatus) {
                            "signin102" -> {
                                //SignIn_102
                                it.empDetail?.let { empDetail ->
                                    Log.d("AuthActivity", "annoucement received ${it.announcement}")
                                    launchUpdateSymptomsFragment(empDetail, it.announcement, true)
                                }

                            }

                            "register101" -> {
                                //Register_101
                                it.empDetail?.let { empDetail ->
                                    Log.d("AuthActivity", "annoucement received ${it.announcement}")
                                    launchUpdateSymptomsFragment(empDetail, it.announcement, false)
                                }

                            }

                            else -> {
                                //Sign_In_101
                                launchResultFragment(it.healthStatus!!, it.empDetail!!)
                            }
                        }
                    }
                }

                data.response?.let { event ->
                    event.peekContent().let { response ->
                        response.message?.let { message ->
                            Log.d("AuthActivity", "response message - $message")
                            if (message.equals(Constants.SIGN_IN_103,true)) {
                                //SignIn103
                                Log.d("AuthActivity", "Show launcher fragment")
                                fragment_container.visibility = View.VISIBLE
                            } else if (message.equals(Constants.REG_102,true)) {
                                //Register_102
                                Log.e(TAG, "Failed Registration.")  //dialog will be handled by BaseActivity
                            } else {

                            }
                        }
                    }
                }
            }
        })
    }

    private fun launchUpdateSymptomsFragment(
        empDetails: EmpDetail?,
        announcement: String?,
        bool: Boolean
    ) {
        Log.d("AuthActivity", "launchUpdateSymptomsFragment: empDetails :$empDetails, announcement :$announcement, register button clicked: $bool")
        val intent = Intent(this, MainActivity::class.java)
        empDetails?.let {
            intent.putExtra(Constants.EMP_DETAIL, empDetails)
        }
        announcement?.let {
            intent.putExtra(Constants.ANNOUNCEMENT, announcement)
        }

        intent.putExtra(Constants.SHOW_DATA_COLLECTION, bool)

        startActivity(intent)
        finish()
    }

    private fun launchResultFragment(color: String, empDetails: EmpDetail) {
        Log.e("AuthActivity", "launchResultFragment: healthStatus: $color , empDetails: $empDetails")
        val intent = Intent(this, MainActivity::class.java)
        intent.putExtra(Constants.HEALTH_STATUS, color)
        intent.putExtra(Constants.EMP_DETAIL, empDetails)
        startActivity(intent)
        finish()
    }

    override fun displayProgressBar(bool: Boolean) {
        if (bool) {
            progress_bar.visibility = View.VISIBLE
        } else {
            progress_bar.visibility = View.GONE
        }
    }

    //If user navigates to other fragment b/w a network request
    override fun onDestinationChanged(
        controller: NavController,
        destination: NavDestination,
        arguments: Bundle?
    ) {
        val vm: AuthViewModel by viewModels()
        vm.cancelActiveJobs()

    }

}
