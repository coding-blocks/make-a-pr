package com.example.covidsymptoms.ui.auth

import androidx.lifecycle.LiveData
import com.example.covidsymptoms.repository.AuthRepository
import com.example.covidsymptoms.ui.BaseViewModel
import com.example.covidsymptoms.ui.DataState
import com.example.covidsymptoms.ui.auth.state.AuthStateEvent
import com.example.covidsymptoms.ui.auth.state.AuthStateEvent.*
import com.example.covidsymptoms.ui.auth.state.AuthViewState
import com.example.covidsymptoms.ui.auth.state.RegistrationFields
import com.example.covidsymptoms.util.AbsentLiveData

class AuthViewModel : BaseViewModel<AuthStateEvent, AuthViewState>() {

    var androidID: String? = ""
    var date: String? = ""

    override fun handleStateEvent(stateEvent: AuthStateEvent): LiveData<DataState<AuthViewState>> {
        when (stateEvent) {

            is SignInAttemptEvent -> {
                return AuthRepository.attemptSignIn(
                    stateEvent.androidId,
                    stateEvent.date
                )
            }

            is RegisterAttemptEvent -> {
                return AuthRepository.attemptRegistration(
                    stateEvent.employeeID,
                    stateEvent.org,
                    stateEvent.androidID
                )
            }

            is None -> return AbsentLiveData.create()
        }
    }

    override fun initNewViewState(): AuthViewState {
        return AuthViewState()
    }

    fun setRegistrationFields(registrationFields: RegistrationFields) {
        val update = getCurrentViewStateOrNew()
        if (update.registrationFields == registrationFields) {
            return
        }
        update.registrationFields = registrationFields
        _viewState.value = update
    }

    fun updateIdAndDate(id: String, currDate: String) {
        androidID = id
        date = currDate
    }

    fun cancelActiveJobs() {
        AuthRepository.cancelActiveJobs()
    }

}