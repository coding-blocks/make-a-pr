package com.example.covidsymptoms.ui.auth

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Observer
import androidx.navigation.fragment.findNavController
import com.afollestad.materialdialogs.MaterialDialog
import com.example.covidsymptoms.R
import com.example.covidsymptoms.repository.AuthRepository
import com.example.covidsymptoms.ui.auth.state.AuthStateEvent
import com.example.covidsymptoms.ui.auth.state.RegistrationFields
import com.example.covidsymptoms.ui.displayErrorDialog
import com.example.covidsymptoms.ui.main.MainActivity
import kotlinx.android.synthetic.main.fragment_launcher.*
import kotlinx.android.synthetic.main.fragment_login.*
import kotlinx.android.synthetic.main.fragment_register.*

class RegisterFragment : Fragment() {

    val TAG = "RegisterFragment"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        /*    Returns a property delegate to access parent activity's ViewModel, if factoryProducer is specified
            then ViewModelProvider.Factory returned by it will be used to create ViewModel first time.Otherwise,
            the activity's androidx.activity.ComponentActivity.getDefaultViewModelProviderFactory will be used*/

        val viewModel: AuthViewModel by activityViewModels()
        Log.e(TAG,"Viewmodel - ${viewModel.hashCode()}")

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        register_button.setOnClickListener {
            register()
        }
        subscribeObservers()
    }

    private fun register(){
        val vm : AuthViewModel by activityViewModels()

        //set field in Viewmodel for retaining fields and stuff
        vm.setRegistrationFields(RegistrationFields(
            empID.text.toString()
        ))

        val empID2 = empID.text.toString()

        //This check can be refactored to be performed in AuthRepository
        val registrationFieldErrors = RegistrationFields(
            empID2).isValidForRegistration()
        //checking employee id first
        if(!(registrationFieldErrors == RegistrationFields.RegistrationError.none())){
            context!!.displayErrorDialog(registrationFieldErrors)                           //Kotlin ViewExtensions used
        }else{
            vm.setStateEvent(AuthStateEvent.RegisterAttemptEvent(
                empID2,
                "SRID",
                AuthRepository.androidID!!
            ))
        }
   /*
        else{
            MaterialDialog(context!!).show {
                title(R.string.personal_data_collection_notice_title)
                message(R.string.personal_data_collection_message)
                positiveButton(R.string.text_agree) {dialog ->

                }
                cancelable(false)
                cancelOnTouchOutside(false)
                negativeButton (R.string.text_disagree)
            }
        }*/
    }

    private fun subscribeObservers(){
        val vm : AuthViewModel by activityViewModels()
        vm.viewState.observe(viewLifecycleOwner, Observer {
            it.registrationFields?.let {
                it.registration_employeeID?.let { empID.setText(it) }
            }
        })
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_register, container, false)
    }

}
