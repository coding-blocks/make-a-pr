package com.example.covidsymptoms.ui.auth.state

sealed class AuthStateEvent{

    data class SignInAttemptEvent(
        val androidId : String,
        val date : String
    ) : AuthStateEvent()

    data class RegisterAttemptEvent(
        val employeeID: String,
        val org : String,
        val androidID : String
    ): AuthStateEvent()

    class None : AuthStateEvent()
}