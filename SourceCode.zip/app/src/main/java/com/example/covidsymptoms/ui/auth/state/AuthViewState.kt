package com.example.covidsymptoms.ui.auth.state

import com.example.covidsymptoms.models.EmpDetail


data class AuthViewState(
    var registrationFields: RegistrationFields? = RegistrationFields(),
    var healthStatus : String? = "NA",
    var empDetail: EmpDetail? = null,
    var announcement: String?=null
)


data class RegistrationFields(
    val registration_employeeID: String? = null
){

    class RegistrationError {
        companion object{

            fun mustFillAllFields(): String{
                return "All fields are required !"
            }

            fun empIdToBeNumeric(): String{
                return "Employee ID must be numeric !"
            }

            fun none():String{
                return "None"
            }

        }
    }

    fun isValidForRegistration(): String{
        if(registration_employeeID.isNullOrBlank()){
            return RegistrationError.mustFillAllFields()
        }

        if(!registration_employeeID.matches(Regex("[0-9]+"))){
            return RegistrationError.empIdToBeNumeric()
        }

        return RegistrationError.none()
    }
}
