package com.example.covidsymptoms.ui.main

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import androidx.navigation.NavController
import androidx.navigation.NavDestination
import androidx.navigation.findNavController
import com.afollestad.materialdialogs.MaterialDialog
import com.afollestad.materialdialogs.callbacks.onDismiss
import com.example.covidsymptoms.R
import com.example.covidsymptoms.models.EmpDetail
import com.example.covidsymptoms.repository.AuthRepository
import com.example.covidsymptoms.ui.BaseActivity
import com.example.covidsymptoms.ui.displayErrorDialog
import com.example.covidsymptoms.ui.main.state.MainStateEvent
import com.example.covidsymptoms.util.Constants
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.fragment_update_symptoms2.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.withContext

class MainActivity : BaseActivity(), NavController.OnDestinationChangedListener {

    //Logic -> if showDataCollectionDialog will come true from AuthActivity , do display it
    //         if  non null annoucement comes from AuthActivity, do display it
    var announcement: String? = null
    var showDataCollectionDialog = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val vm: MainViewModel by viewModels()

        val healthStatus: String? = intent.getStringExtra(Constants.HEALTH_STATUS)
        val empDetails: EmpDetail? = intent.getParcelableExtra(Constants.EMP_DETAIL)
        announcement = intent.getStringExtra(Constants.ANNOUNCEMENT)
        showDataCollectionDialog = intent.getBooleanExtra(Constants.SHOW_DATA_COLLECTION, false)

        healthStatus?.let {
            Log.d("MainActivity", "SuccessFul SignIn(101) with healthStatus - $it")
            vm.setStatus(it)  //navigates to result page
        }

        //empdetails should never be null (passed in both cases , Successful Sign in , Successful Registration)
        empDetails?.let {
            Log.d("MainActivity", "empDetails from authactivity - $it")
            vm.setEmployee(it)
        }


        findNavController(R.id.main_nav_host_fragment).addOnDestinationChangedListener(this)
        subscribeObservers()
    }

    private fun subscribeObservers() {
        val vm: MainViewModel by viewModels()
        vm.viewState?.observe(this, Observer { viewState ->
            viewState.updationFields.let {
                //navigate to reportFragment with this result
                when (it.healthStatus) {

                    //Successful Registration(101) or 1st time subscribing
                    "notSet" -> {
                        //UpdateSymptomsFragment is executing call for GetQuestionsEvent
                    }

                    //Successful signIn + Questionnaire Expired
                    "NA" -> {
                        //UpdateSymptomsFragment is executing call for GetQuestionsEvent
                    }

                    //Above checks are for modularity if required for specific health status cases
                    //Successful signIn + Questionnaire also okay
                    else -> {
                        Log.d("MainActivity", "Navigate to reportFragment")
                        findNavController(R.id.main_nav_host_fragment).navigate(R.id.action_updateSymptomsFragment_to_reportFragment)
                        fragment_container.visibility = View.VISIBLE
                    }
                }
            }
        })


        vm.dataState?.observe(this, Observer {
            onDataStateChange(it)
            //The code to setViewState on getting list can be refactored to UpdateSymptomsFragment
            it.data?.let {
                it.data?.let { event ->
                    event.getContentIfNotHandled()?.let {viewState ->
                        Log.d(
                            "MainActivity",
                            "QuestionList set to recyclerView : ${viewState.updationFields.questionList}"
                        )
                        vm.setQuestionListData(viewState.updationFields.questionList)
                    }

                }
                //peeking as i need to pass errors(apart from these specific ones) to BaseActivity
                it.response?.let { event ->
                    event.peekContent().message?.let { message ->
                        if (message == Constants.QUESLIST_OK) {
                            Log.d("MainActivity", "Successful Loading of Questions")
                            fragment_container.visibility = View.VISIBLE

                            showDialogs()
                            //show both
//                            } else {
//                                showAnnouncementDialog()        //show only announcement
//                            }
                        }

                        if (message == Constants.QUESLIST_FAIL) {
                            Log.e(
                                "MainActivity",
                                "QuesList may be null ??"
                            )
                            fragment_container.visibility = View.VISIBLE
                            event.getContentIfNotHandled()
                        }
                    }
                }
            }
        })
    }

    private fun showDialogs() {
        Log.e(
            "MainActivity",
            "showDialogs()"
        )
            MaterialDialog(this).show {
                title(R.string.personal_data_collection_notice_title)
                message(R.string.personal_data_collection_message)
                positiveButton(R.string.text_agree) {
                    showAnnouncementDialog()
                }
                cancelable(false)
                cancelOnTouchOutside(false)
                negativeButton(R.string.text_disagree) {
                    finish()
                }
            }
    }

    private fun showAnnouncementDialog() {
        Log.e(
            "MainActivity",
            "showAnnouncementDialog() called with announcement = $announcement"
        )
        announcement?.let {
            MaterialDialog(this).show {
                title(R.string.admin_announcement)
                message(text = announcement)
                positiveButton(R.string.text_ok)
                cancelable(false)
                cancelOnTouchOutside(false)
            }
        }
    }


    override fun displayProgressBar(bool: Boolean) {
        if (bool) {
            progress_bar.visibility = View.VISIBLE
        } else {
            progress_bar.visibility = View.GONE
        }
    }

    override fun onDestinationChanged(
        controller: NavController,
        destination: NavDestination,
        arguments: Bundle?
    ) {
        val vm: MainViewModel by viewModels()
        vm.cancelActiveJobs()
    }

    //This can be refactored later
    private var doubleBackToExitPressedOnce = false

    override fun onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            finish()
            return
        }

        Log.e("MainActivity"," Call for toast to show !!!")
        this.doubleBackToExitPressedOnce = true
        Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show()

        Handler().postDelayed(Runnable { doubleBackToExitPressedOnce = false }, 2000)
    }
}
