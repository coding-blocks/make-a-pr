package com.example.covidsymptoms.ui.main

import android.util.Log
import android.view.KeyEvent
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.AdapterView
import android.widget.CheckBox
import android.widget.EditText
import android.widget.Spinner
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.covidsymptoms.R
import com.example.covidsymptoms.models.Question
import com.example.covidsymptoms.util.Constants.Companion.CHECKBOX_TYPE
import com.example.covidsymptoms.util.Constants.Companion.EDITBOX_TYPE
import com.example.covidsymptoms.util.Constants.Companion.GROUP_TYPE
import com.example.covidsymptoms.util.Constants.Companion.OTHER_TYPE
import com.example.covidsymptoms.util.Constants.Companion.SPINNER_TYPE
import kotlinx.android.synthetic.main.layout_checkbox_list_item.view.*
import kotlinx.android.synthetic.main.layout_checkbox_list_item.view.item_checkBox
import kotlinx.android.synthetic.main.layout_editbox_list_item.view.*
import kotlinx.android.synthetic.main.layout_group_list_item.view.*
import kotlinx.android.synthetic.main.layout_othertype_list_item.view.*
import kotlinx.android.synthetic.main.layout_spinner_list_item.view.*
import kotlinx.android.synthetic.main.layout_view_type_104.view.*


class QuestionListAdapter(private val interaction: Interaction? = null) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    val DIFF_CALLBACK = object : DiffUtil.ItemCallback<Question>() {

        override fun areItemsTheSame(oldItem: Question, newItem: Question): Boolean {
            return oldItem.questionStr.equals(newItem.questionStr,true)
        }

        override fun areContentsTheSame(oldItem: Question, newItem: Question): Boolean {
            return oldItem == newItem
        }

    }
    private val differ = AsyncListDiffer(this, DIFF_CALLBACK)

    override fun getItemViewType(position: Int): Int {
        // for Difference in checkBoxTypeHOlder and  OtherViewTypeHOlder
        if(differ.currentList[position].viewType == 101){
            //hard coding here
            if(differ.currentList[position].hasChildren){
                return OTHER_TYPE;
            }
        }
        Log.d("QuestionListAdapter","getItemViewType() - ${differ.currentList[position].viewType} returned")
        return differ.currentList[position].viewType
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {

        when(viewType){

            //101
            CHECKBOX_TYPE -> {
                return CheckBoxTypeHolder(
                    LayoutInflater.from(parent.context).inflate(
                        R.layout.layout_checkbox_list_item,
                        parent,
                        false
                    ),
                    interaction
                )
            }

            //102
            EDITBOX_TYPE -> {
                return EditBoxTypeHolder(
                    LayoutInflater.from(parent.context).inflate(
                        R.layout.layout_editbox_list_item,
                        parent,
                        false
                    ),
                    interaction
                )
            }

            //103
            SPINNER_TYPE ->{
                return SpinnerTypeHolder(
                    LayoutInflater.from(parent.context).inflate(
                        R.layout.layout_spinner_list_item,
                        parent,
                        false
                    ),
                    interaction
                )
            }

            //104
            GROUP_TYPE ->{
                return GroupTypeHolder(
                    LayoutInflater.from(parent.context).inflate(
                        R.layout.layout_view_type_104,
                        parent,
                        false
                    ),
                    interaction
                )
            }

            //105
            OTHER_TYPE ->{
                return OtherTypeHolder(
                    LayoutInflater.from(parent.context).inflate(
                        R.layout.layout_othertype_list_item,
                        parent,
                        false
                    ),
                    interaction
                )
            }

            //not going to happen
            else ->{
                return CheckBoxTypeHolder(
                    LayoutInflater.from(parent.context).inflate(
                        R.layout.layout_checkbox_list_item,
                        parent,
                        false
                    ),
                    interaction
                )
            }

        }

    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder) {
            is CheckBoxTypeHolder -> {
                holder.bind(differ.currentList[position])
            }
            is EditBoxTypeHolder -> {
                holder.bind(differ.currentList[position])
            }

            is SpinnerTypeHolder -> {
                holder.bind(differ.currentList[position])
            }

            is GroupTypeHolder -> {
                holder.bind(differ.currentList[position])
            }

            is OtherTypeHolder -> {
                holder.bind(differ.currentList[position])
            }
        }
    }

    override fun getItemCount(): Int {
        return differ.currentList.size
    }

    fun submitList(list: List<Question>) {
        differ.submitList(list)
    }

    class CheckBoxTypeHolder
    constructor(
        itemView: View,
        private val interaction: Interaction?
    ) : RecyclerView.ViewHolder(itemView) {

        fun bind(ques: Question) = with(itemView) {
            itemView.setOnClickListener {
                interaction?.onItemSelected(adapterPosition, ques)
            }
            item_checkBoxTV.text = ques.questionStr

            //updating the question if user clicks checkbox of a PARENT
                item_checkBox.setOnClickListener{
                    Log.d("QuestionListAdapter","CheckBoxTypeHolder onClick of  Question called")
                    ques.checkboxAns = item_checkBox.isChecked
                }
            }

        }


    class EditBoxTypeHolder
    constructor(
        itemView: View,
        private val interaction: Interaction?
    ) : RecyclerView.ViewHolder(itemView) {

        fun bind(ques: Question) = with(itemView) {
            itemView.setOnClickListener {
                interaction?.onItemSelected(adapterPosition, ques)
            }
            item_editBoxTV.setText(ques.questionStr)
            item_editTextBox.setText(ques.editboxAns)

            //updating the list

            item_editBoxTV.setOnFocusChangeListener( object : View.OnFocusChangeListener{
                override fun onFocusChange(v: View?, hasFocus: Boolean) {
                    Log.d("QuestionListAdapter","OtherTypeHolder saving furtherQuesEditBoxAns ")
                    if(!hasFocus) {
                        ques.editboxAns  = (v as EditText).text.toString()
                    }
                }

            })
        }
    }

    class SpinnerTypeHolder
    constructor(
        itemView: View,
        private val interaction: Interaction?
    ) : RecyclerView.ViewHolder(itemView) {

        fun bind(ques: Question) = with(itemView) {
            itemView.setOnClickListener {
                interaction?.onItemSelected(adapterPosition, ques)
            }

            val mAdapter = MySpinnerAdapter(context,R.layout.layout_spinner_option_row,ques.spinnerStr)
            item_spinner.adapter = mAdapter

            item_spinnerTV.setText(ques.questionStr)
            item_spinner.setSelection(ques.selected_val)

            //updating question according to option chosen
            item_spinner?.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
                override fun onNothingSelected(parent: AdapterView<*>?) {
                }

                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    Log.d("QuestionListAdapter","SpinnerTypeHolder saving selected value  - $position")
                    ques.selected_val = position
                }

            }


        }
    }


    class OtherTypeHolder
    constructor(
        itemView: View,
        private val interaction: Interaction?
    ) : RecyclerView.ViewHolder(itemView) {

        fun bind(ques: Question) = with(itemView) {
            itemView.setOnClickListener {
                interaction?.onItemSelected(adapterPosition, ques)
            }

            item_otherQuesTitleTV.setText(ques.questionStr)
            item_furtherQuesTV.setText(ques.children[0].questionStr)



            item_otherQuesTitleCheckBox.setOnClickListener {v ->
                Log.d("QuestionListAdapter","OtherTypeHolder checkBox was clicked ")
                if((v as CheckBox).isChecked){
                    Log.d("QuestionListAdapter","OtherTypeHolder enabling furtherQues ")
                    ques.checkboxAns = true
                    item_furtherQuesEditBox.isEnabled = true
                    item_furtherQuesTV.isEnabled = true
                }else{
                    Log.d("QuestionListAdapter","OtherTypeHolder disabling furtherQues ")
                    item_furtherQuesEditBox.setText("")
                    ques.checkboxAns = false
                    item_furtherQuesEditBox.isEnabled = false
                    item_furtherQuesTV.isEnabled = false
                }
            }

            //updating answer
            item_furtherQuesEditBox.setOnFocusChangeListener( object : View.OnFocusChangeListener{
                override fun onFocusChange(v: View?, hasFocus: Boolean) {
                    Log.d("QuestionListAdapter","OtherTypeHolder saving furtherQuesEditBoxAns ")
                    if(!hasFocus) {
                        ques.editboxAns  = (v as EditText).text.toString()
                    }
                }

            })

        }
    }

    class GroupTypeHolder
    constructor(
        itemView: View,
        private val interaction: Interaction?
    ) : RecyclerView.ViewHolder(itemView) {

        fun bind(ques: Question) = with(itemView) {
            itemView.setOnClickListener {
                interaction?.onItemSelected(adapterPosition, ques)
            }

            val subQuestionList = ques.children
            group_question_title.setText(ques.questionStr)

            item_checkBoxTV_1.setText(subQuestionList[0].questionStr)
            item_checkBox_1.setOnClickListener{
                Log.d("QuestionListAdapter","GroupTypeHolder onClick of subQues 1 called")
                subQuestionList[0].checkboxAns = item_checkBox_1.isChecked
                item_checkBox_5.isChecked = false

            }

            item_checkBoxTV_2.setText(subQuestionList[1].questionStr)
            item_checkBox_2.setOnClickListener{
                Log.d("QuestionListAdapter","GroupTypeHolder onClick of subQues 2 called")
                subQuestionList[1].checkboxAns = item_checkBox_2.isChecked
                item_checkBox_5.isChecked = false
            }

            item_checkBoxTV_3.setText(subQuestionList[2].questionStr)
            item_checkBox_3.setOnClickListener{
                Log.d("QuestionListAdapter","GroupTypeHolder onClick of subQues 3 called")
                subQuestionList[2].checkboxAns = item_checkBox_3.isChecked
                item_checkBox_5.isChecked = false
            }

            item_checkBoxTV_4.setText(subQuestionList[3].questionStr)
            item_checkBox_4.setOnClickListener{
                Log.d("QuestionListAdapter","GroupTypeHolder onClick of subQues 4 called")
                subQuestionList[3].checkboxAns = item_checkBox_4.isChecked
                item_checkBox_5.isChecked = false
            }

            item_checkBoxTV_5.setText(subQuestionList[4].questionStr)
            item_checkBox_5.setOnClickListener{
                Log.d("QuestionListAdapter","GroupTypeHolder onClick of subQues 5 called")
                subQuestionList[4].checkboxAns = item_checkBox_5.isChecked
                item_checkBox_1.isChecked = false
                item_checkBox_2.isChecked = false
                item_checkBox_3.isChecked = false
                item_checkBox_4.isChecked = false
            }

        }

    }

    fun getSymptomsCheckedStatus():Boolean{
        var noSymptomSelected = true
        Log.e("QuestionAdapter","getSymptomsCheckedStatus - $noSymptomSelected")
        for( parentQuestion:Question in differ.currentList ){
            if(parentQuestion.viewType == GROUP_TYPE){
                var childQuestions = parentQuestion.children
                if(childQuestions.size>1){
                    for( childQuestion in childQuestions){
                        if(childQuestion.checkboxAns){
                            if(!noSymptomSelected) break
                            noSymptomSelected = false
                        }
                    }
                }
            }
        }
        return noSymptomSelected
    }

    private fun updateStatus(currStatus : String , quesImpact : String ) : String{
        var retVal = ""
        if(currStatus == "Red"){
            retVal = currStatus
        }

        if(currStatus == "Orange"){
            if(quesImpact == "Red"){
                retVal = quesImpact
            }else{
                retVal = currStatus
            }
        }

        if(currStatus == "Green") {
            if(quesImpact != "none"){
                retVal = quesImpact
            }else{
                retVal = currStatus
            }
        }

        return retVal
    }

    fun calculateHealthStatus(): String{
        var currentHealthStatus = "Green"
        for( parentQuestion:Question in differ.currentList ){
            if(currentHealthStatus == "Red") break

            //currentHealthStatus is orange/green
            when(parentQuestion.viewType){
                CHECKBOX_TYPE ->{
                    if(parentQuestion.checkboxAns) {
                        Log.d(
                            "QuestionAdapter",
                            "Health Status updated to  -${parentQuestion.impactOnStatus} from $currentHealthStatus"
                        )
                        currentHealthStatus = updateStatus(currentHealthStatus, parentQuestion.impactOnStatus)
                    }
                }

                GROUP_TYPE -> {
                    val childQuestions = parentQuestion.children

                    if(childQuestions[childQuestions.size-1].checkboxAns ){
                        //if none of the above is checked ::Assumption -> it is the last item in childQuestions list
                        Log.d("QuestionAdapter","None of the above was  checked")
                    }else{
                        for( childQuestion in childQuestions){
                            if(childQuestion.checkboxAns){
                                //do not check futher if red also, i need to check if atleast one of the child here is enabled
                                Log.d("QuestionAdapter","Health Status updated to  -${childQuestion.impactOnStatus}from $currentHealthStatus")
                                currentHealthStatus = updateStatus(currentHealthStatus,childQuestion.impactOnStatus)
                                if(currentHealthStatus == "Red") break
                            }
                        }
                    }
                }

                OTHER_TYPE -> {
                    if(parentQuestion.checkboxAns) {
                        Log.d(
                            "QuestionAdapter",
                            "Health Status updated to  -${parentQuestion.impactOnStatus} from $currentHealthStatus"
                        )
                        currentHealthStatus = updateStatus(currentHealthStatus, parentQuestion.impactOnStatus)
                    }
                }
                else -> {
                    //no contribution in score
                }
            }
        }
        return currentHealthStatus
    }


    interface Interaction {
        fun onItemSelected(position: Int, item: Question)
    }
}

