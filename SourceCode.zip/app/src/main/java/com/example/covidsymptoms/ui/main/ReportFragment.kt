package com.example.covidsymptoms.ui.main

import android.graphics.Typeface
import android.os.Bundle
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.afollestad.materialdialogs.MaterialDialog
import com.afollestad.materialdialogs.callbacks.onDismiss
import com.afollestad.materialdialogs.customview.customView
import com.afollestad.materialdialogs.customview.getCustomView
import com.example.covidsymptoms.R
import com.example.covidsymptoms.repository.AuthRepository
import com.example.covidsymptoms.ui.displayErrorDialog
import com.example.covidsymptoms.ui.main.state.MainStateEvent
import com.example.covidsymptoms.ui.main.state.MainViewState
import com.example.covidsymptoms.util.Constants
import com.example.covidsymptoms.util.DateUtils
import kotlinx.android.synthetic.main.fragment_report.*

class ReportFragment : Fragment() {

    val TAG = "ReportFragment"

    private var clickCount =0
    private var isTestModeEnabled = false
    private var previousTime = 0L
    private var dialogShowing = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        /*    Returns a property delegate to access parent activity's ViewModel, if factoryProducer is specified
            then ViewModelProvider.Factory returned by it will be used to create ViewModel first time.Otherwise,
            the activity's androidx.activity.ComponentActivity.getDefaultViewModelProviderFactory will be used*/

        val viewModel: MainViewModel by activityViewModels()
        Log.d(TAG, "Viewmodel - ${viewModel.hashCode()}")


    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        entryStatusIcon.setOnClickListener {
            onClickTestMode()                                         //disabled for now
        }

        val viewModel: MainViewModel by activityViewModels()
        val empDetails =  viewModel.currEmpDetail

        greetingTV.setText("Hi ${empDetails?.name}," +
                "\nEMP ID:\t ${empDetails?.empID}" +
                "\nORG NAME:\t ${empDetails?.orgName}" +
                "\nDATE:\t ${DateUtils.getCurrentDate()}" +
                "\nTIME:\t ${DateUtils.getTime()} Hrs"
                )

        /*if(BuildConfig.VERSION_NAME == "1.0 - test"){
            testing_deleteRecord.visibility = View.VISIBLE
        }*/

        helpLine.setText("Valid till today 11:59 p.m. \n" +
                "Helpline no. - +919717066884")

        when (viewModel.getCurrentViewStateOrNew().updationFields.healthStatus) {
            "Red" -> {
                Log.d("ReportFragment", "color - red")
                resultColorView.setBackgroundColor(resources.getColor(R.color.red))
                messageTV.setText(R.string.red_indication_result)
                messageTV.setTypeface(null,Typeface.BOLD)
                entryStatusIcon.setImageResource(R.drawable.prohibited)
                entryStatus.setText(R.string.red_result_title)
            }

            "Orange" -> {
                Log.d("ReportFragment", "color - orange")
                resultColorView.setBackgroundColor(resources.getColor(R.color.orange))
                messageTV.setText(R.string.orange_indication_result)
                entryStatusIcon.setImageResource(R.drawable.medical)
                entryStatus.setText(R.string.orange_result_title)
            }

            "Green" -> {
                Log.d("ReportFragment", "color - green")
                resultColorView.setBackgroundColor(resources.getColor(R.color.green))
                messageTV.setText(R.string.green_indication_result)
                entryStatusIcon.setImageResource(R.drawable.permitted)
                entryStatus.setText(R.string.green_result_title)
            }

            else -> {
                Log.e(
                    "ReportFragment",
                    "color - error with healthStatus being - ${viewModel.getCurrentViewStateOrNew().updationFields.healthStatus}"
                )
            }

        }

    }

    private fun onClickTestMode() {
        if(isTestModeEnabled && !dialogShowing){
            showDialogForReset()
        }
        var currentTime = System.currentTimeMillis()

        if(clickCount ==0){
            previousTime = System.currentTimeMillis()
        }

        if(currentTime- previousTime <300 ) {
            clickCount++
            previousTime = currentTime
        }else{
            clickCount = 0
        }


        if(clickCount >= Constants.COUNT_FOR_ENABLE_TESTER_MODE){
            Toast.makeText(context,"Test Mode Enabled!!",Toast.LENGTH_SHORT).show()
            isTestModeEnabled = true
        }

    }

    private fun showDialogForReset(){
        dialogShowing = true
        val vm : MainViewModel by activityViewModels()
        MaterialDialog(context!!).show {
            customView(R.layout.testmode_reset_record)
            positiveButton(R.string.text_ok){dialog ->
                //make request to server!
                val empidET = dialog.getCustomView().findViewById<EditText>(R.id.testEmpID)
                val pwdET = dialog.getCustomView().findViewById<EditText>(R.id.testPwdResetID)
                if(passChecks(empidET,pwdET)){
                    vm.setStateEvent(MainStateEvent.DeleteRecordEvent(empidET.text.toString().toInt()))
                }
            }
            onDismiss {
                dialogShowing = false
            }
            cancelOnTouchOutside(false)
        }
    }

    private fun passChecks(empidET:EditText,pwdET : EditText) : Boolean {
        if(empidET.text.toString() == "" || pwdET.text.toString() == ""){
            context!!.displayErrorDialog("All fields must be filled!")
            return false
        }else{
            Log.e("ReportFragment","Resetting employee id = ${empidET.text.toString().toInt()}")
        }

        if(pwdET.text.toString() != Constants.HARDCODED_TESTING_PWD){
            context!!.displayErrorDialog("Wrong Password!")
            return false
        }
        return true
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_report, container, false)
    }
}