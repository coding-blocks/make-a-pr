package com.example.covidsymptoms.ui.main

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.covidsymptoms.R
import com.example.covidsymptoms.models.Question

//Not used for now, hard coded stuff
class SubQuestionListAdapter(var subQuestionList: List<Question>): RecyclerView.Adapter<QuestionListAdapter.CheckBoxTypeHolder>(){
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): QuestionListAdapter.CheckBoxTypeHolder {
        return QuestionListAdapter.CheckBoxTypeHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.layout_checkbox_list_item,
                parent,
                false
            ),null
        )
    }

    override fun getItemCount(): Int {
        return subQuestionList.size
    }

    override fun onBindViewHolder(holder: QuestionListAdapter.CheckBoxTypeHolder, position: Int) {
        //Each subGroupQuestion will only be checkBox style with no children
        val currItem  = subQuestionList[position];
        holder.bind(currItem)
    }

}