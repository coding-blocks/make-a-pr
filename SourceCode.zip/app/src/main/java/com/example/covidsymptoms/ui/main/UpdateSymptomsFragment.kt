package com.example.covidsymptoms.ui.main

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Observer
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.afollestad.materialdialogs.MaterialDialog
import com.afollestad.materialdialogs.callbacks.onDismiss
import com.example.covidsymptoms.R
import com.example.covidsymptoms.models.Question
import com.example.covidsymptoms.repository.AuthRepository
import com.example.covidsymptoms.ui.main.state.MainStateEvent
import com.example.covidsymptoms.util.Constants
import com.example.covidsymptoms.util.TopSpacingItemDecoration
import kotlinx.android.synthetic.main.fragment_update_symptoms2.*

class UpdateSymptomsFragment : Fragment(),QuestionListAdapter.Interaction {
    override fun onItemSelected(position: Int, item: Question) {
        //do nothing right now
    }

    val TAG = "UpdateSymptomsFragment"

    private lateinit var recyclerAdapter : QuestionListAdapter
    var healthStatus_calculated = "NotYet"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        /*    Returns a property delegate to access parent activity's ViewModel, if factoryProducer is specified
            then ViewModelProvider.Factory returned by it will be used to create ViewModel first time.Otherwise,
            the activity's androidx.activity.ComponentActivity.getDefaultViewModelProviderFactory will be used*/

        val viewModel: MainViewModel by activityViewModels()

        Log.d(TAG,"Viewmodel - ${viewModel.hashCode()}")
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        update_button.setOnClickListener {
            updateChangesToServer()
        }
        val vm: MainViewModel by activityViewModels()
        initRecyclerView()
        subscribeObservers()

        //make get questionnaire call
        vm.setStateEvent(
            MainStateEvent.GetQuestionsEvent(
                AuthRepository.androidID!!,
                AuthRepository.date!!))

    }
    private fun updateChangesToServer(){
        val vm : MainViewModel by activityViewModels()

        val noSymptomChecked  = recyclerAdapter.getSymptomsCheckedStatus()
        Log.e("UpdateSymptomsFragment","noSymptomChecked = $noSymptomChecked")

        if(noSymptomChecked){
            MaterialDialog(context!!).show {
                title(R.string.text_error)
                message ( R.string.no_symptom_selected )
                positiveButton(R.string.text_ok)
                cancelable(false)
                cancelOnTouchOutside(false)
            }
        }else{
            val healthStatus = recyclerAdapter.calculateHealthStatus()                  //runs the test
            Log.e("UpdateSymptomsFragment"," healthStatus = $healthStatus")
            healthStatus_calculated = healthStatus
            MaterialDialog(context!!).show {
                title(R.string.employee_undertaking_title)
                message(R.string.employee_undertaking_message)
                positiveButton(R.string.text_ok){
                    //Toast.makeText(context,"The status to be sent is - $healthStatus",Toast.LENGTH_SHORT).show()
                    vm.setStateEvent(MainStateEvent.UpdateEvent(healthStatus,vm.getCurrentViewStateOrNew().updationFields.questionList))
                }
                cancelable(false)
                cancelOnTouchOutside(false)
                negativeButton (R.string.text_cancel)
            }
        }
    }

    private fun initRecyclerView(){
        questionRV.apply {
            layoutManager = LinearLayoutManager(this@UpdateSymptomsFragment.context)

            recyclerAdapter = QuestionListAdapter(this@UpdateSymptomsFragment)
            val topSpacingItemDecorator = TopSpacingItemDecoration(30)
            removeItemDecoration(topSpacingItemDecorator)
            addItemDecoration(topSpacingItemDecorator)
            adapter = recyclerAdapter
        }
    }

    private fun subscribeObservers(){
        val vm : MainViewModel by activityViewModels()

        vm.dataState.observe(viewLifecycleOwner, Observer {dataState ->
            dataState?.let {dataState ->
                dataState.data?.let {
                    it.response?.let {event ->
                        event.peekContent()?.let {response ->
                            if(response.message.equals(Constants.UPDATION_101)){
                                vm.setStatus(healthStatus_calculated)
                            }
                            if(response.message == Constants.QUESLIST_FAIL){
                                Log.e("UpdateSymptomsFragment","Since question list not available, showing textview")
                                error_null_quesV.visibility = View.VISIBLE
                            }

                            if(response.message == Constants.QUESLIST_OK){
                                Log.d("UpdateSymptomsFragment",",Successful Loading of Questions showing scrollview")
                                success_quesV.visibility = View.VISIBLE
                            }
                        }
                    }
                }
            }
        })

        //changes after i change from mainactivity
        vm.viewState.observe(viewLifecycleOwner, Observer {viewState ->
            viewState?.let {
                Log.d("UpdateSymptomsFragment","submit list - ${it.updationFields.questionList}")
                recyclerAdapter.submitList(it.updationFields.questionList)
            }
        })
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_update_symptoms2, container, false)
    }

}
