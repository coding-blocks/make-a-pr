package com.example.covidsymptoms.ui.main.state

import com.example.covidsymptoms.models.EmpDetail
import com.example.covidsymptoms.models.Question

data class MainViewState(
    var updationFields: UpdationFields = UpdationFields()
)

data class UpdationFields(
    var questionList: List<Question> = ArrayList(),
    var healthStatus: String = "notSet"
) {
    override fun toString(): String {
        return "UpdationFields(questionList=$questionList)"
    }
}

