package com.example.covidsymptoms.util

class Constants {

    companion object{

        const val HARDCODED_TESTING_PWD = "QwErTy@9876"
        const val COUNT_FOR_ENABLE_TESTER_MODE = 10

        //viewTypes coming from server
        const val CHECKBOX_TYPE = 101
        const val EDITBOX_TYPE  = 102   //not using right now
        const val SPINNER_TYPE = 103
        const val GROUP_TYPE = 104

        //my own handling
        const val OTHER_TYPE = 105


        //Successful HTTP OK

            //signIN
            const val SIGN_IN_101 = "Sign In okay, Questionnaire filled"
            const val SIGN_IN_102 = "Sign In okay , Questionnaire expired"
            const val SIGN_IN_103 = "Sign In failed"

            //Successful loading of questionList (not null)
            const val QUESLIST_OK = "Successful Loading of Questions"
            const val QUESLIST_FAIL = "QuestionList not available"

            //registration
            const val REG_101 = "Registration Successful"
            const val REG_102 = "Registration Failed"

            //updation
            const val UPDATION_101 = "Update Successful"

        //navigating to mainAct
            const val HEALTH_STATUS = "healthStatus"
            const val EMP_DETAIL = "empDetail"
            const val ANNOUNCEMENT = "announcement"
            const val SHOW_DATA_COLLECTION = "show dialog"

        const val NETWORK_TIMEOUT = 6000L
        const val TESTING_NETWORK_DELAY = 0L // fake network delay for testing


    }
}