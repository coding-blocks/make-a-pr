package com.example.covidsymptoms.util

object MyUrls {

    //TODO : set default url here
    var BASE_URL = "http://18.208.67.134/" ;

    fun setBaseUrl(str : String){
        BASE_URL = str
    }
}