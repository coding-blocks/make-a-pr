package com.example.covidsymptoms.util

import com.example.covidsymptoms.api.main.responses.QuestionnaireResponse
import com.example.covidsymptoms.models.Question
import com.google.gson.Gson

//not used now
object testArrayListOfQuestions {

    var testingArrayList: ArrayList<Question> = ArrayList()

    init {
        //Has 4 questions hardcoded

    }
}
    /*fun fillList(){
      val gson = Gson()
      val jsonStr = "{ \n" +
              "\t\"healthstatus\" : \"\",\n" +
              "\t\"questions\" : [ \n" +
              "\t\t{ \t\n" +
              "\t\t\t\t\"viewtype\"\t\t: 101,\n" +
              "\t\t\t\t\"questionstr\" \t: \"Have you been on any international travel in past 14 days ?\",\n" +
              "\t\t\t\t\"editboxans\"\t\t: \"\",\n" +
              "\t\t\t\t\"checkboxans\"\t: false,\n" +
              "\t\t\t\t\"haschildren\"\t\t: false,\n" +
              "\t\t\t\t\"children\"\t\t: [],\t\t\t\n" +
              "\t\t\t\t\"spinnerstr\"     : [],\t\n" +
              "\t\t\t\t\"selectedval\"    : 0,\n" +
              "\t\t\t\t\"impactonstatus\" : \"red\"\n" +
              "\t\t},\n" +
              "\t\t{ \t\n" +
              "\t\t\t\t\"viewtype\"\t\t: 101,\n" +
              "\t\t\t\t\"questionstr\" \t: \"Have you come in contact or lived with any Covid-19 infected person within past 14 days ?\",\n" +
              "\t\t\t\t\"editboxans\"\t\t: \"\",\n" +
              "\t\t\t\t\"checkboxans\"\t: false,\n" +
              "\t\t\t\t\"haschildren\"\t\t: false,\n" +
              "\t\t\t\t\"children\"\t\t: [],\t\t\t\n" +
              "\t\t\t\t\"spinnerstr\"     : [],\t\n" +
              "\t\t\t\t\"selectedval\"    : 0,\n" +
              "\t\t\t\t\"impactonstatus\" : \"red\"\t\t\n" +
              "\t\t},\n" +
              "\t\t{ \t\n" +
              "\t\t\t\t\"viewtype\"\t\t: 101,\n" +
              "\t\t\t\t\"questionstr\" \t: \"Have you undergone any COVID-19 Test in past 14 days ?\",\n" +
              "\t\t\t\t\"editboxans\"\t\t: \"\",\n" +
              "\t\t\t\t\"checkboxans\"\t: false,\n" +
              "\t\t\t\t\"haschildren\"\t\t: false,\n" +
              "\t\t\t\t\"children\"\t\t: [],\t\t\t\n" +
              "\t\t\t\t\"spinnerstr\"     : [] ,\t\n" +
              "\t\t\t\t\"selectedval\"    : 0,\n" +
              "\t\t\t\t\"impactonstatus\" : \"orange\"\n" +
              "\t\t},\n" +
              "\t\t{ \t\n" +
              "\t\t\t\t\"viewtype\"\t\t: 101,\n" +
              "\t\t\t\t\"questionstr\" \t: \"Is your Society / Locality identified by Government records as Red Containment zone?\",\n" +
              "\t\t\t\t\"editboxans\"\t\t: \"\",\n" +
              "\t\t\t\t\"checkboxans\"\t: false,\n" +
              "\t\t\t\t\"haschildren\"\t\t: false,\n" +
              "\t\t\t\t\"children\"\t\t: [],\t\t\t\n" +
              "\t\t\t\t\"spinnerstr\"     : [],\t\n" +
              "\t\t\t\t\"selectedval\"    : 0,\n" +
              "\t\t\t\t\"impactonstatus\" : \"red\"\n" +
              "\t\t},\n" +
              "\t\t{ \t\n" +
              "\t\t\t\t\"viewtype\"\t\t: 104,\n" +
              "\t\t\t\t\"questionstr\" \t: \"Do you face any of the following symptoms?\",\n" +
              "\t\t\t\t\"editboxans\"\t\t: \"\",\n" +
              "\t\t\t\t\"checkboxans\"\t: false,\n" +
              "\t\t\t\t\"haschildren\"\t\t: true,\n" +
              "\t\t\t\t\"children\"\t\t: [\n" +
              "\t\t\t\t\t{ \t\n" +
              "\t\t\t\t\t\t\"viewtype\"\t\t: 101,\n" +
              "\t\t\t\t\t\t\"questionstr\" \t: \"Fever\",\n" +
              "\t\t\t\t\t\t\"editboxans\"\t\t: \"\",\n" +
              "\t\t\t\t\t\t\"checkboxans\"\t: false,\n" +
              "\t\t\t\t\t\t\"haschildren\"\t\t: false,\n" +
              "\t\t\t\t\t\t\"children\"\t\t: [],\t\t\t\n" +
              "\t\t\t\t\t\t\"spinnerstr\"     : [],\t\n" +
              "\t\t\t\t\t\t\"selectedval\"    : 0,\n" +
              "\t\t\t\t\t\t\"impactonstatus\" : \"orange\"\n" +
              "\t\t\t\t\t},\n" +
              "\t\t\t\t\t{ \t\n" +
              "\t\t\t\t\t\t\"viewtype\"\t\t: 101,\n" +
              "\t\t\t\t\t\t\"questionstr\" \t: \"Dry Cough / Cold\",\n" +
              "\t\t\t\t\t\t\"editboxans\"\t\t: \"\",\n" +
              "\t\t\t\t\t\t\"checkboxans\"\t: false,\n" +
              "\t\t\t\t\t\t\"haschildren\"\t\t: false,\n" +
              "\t\t\t\t\t\t\"children\"\t\t: [],\t\t\t\n" +
              "\t\t\t\t\t\t\"spinnerstr\"     : [],\t\n" +
              "\t\t\t\t\t\t\"selectedval\"    : 0,\n" +
              "\t\t\t\t\t\t\"impactonstatus\" : \"orange\"\n" +
              "\t\t\t\t\t},\n" +
              "\t\t\t\t\t{ \t\n" +
              "\t\t\t\t\t\t\"viewtype\"\t\t: 101,\n" +
              "\t\t\t\t\t\t\"questionstr\" \t: \"Sore Throat\",\n" +
              "\t\t\t\t\t\t\"editboxans\"\t\t: \"\",\n" +
              "\t\t\t\t\t\t\"checkboxans\"\t: false,\n" +
              "\t\t\t\t\t\t\"haschildren\"\t\t: false,\n" +
              "\t\t\t\t\t\t\"children\"\t\t: [],\t\t\t\n" +
              "\t\t\t\t\t\t\"spinnerstr\"     : [],\t\n" +
              "\t\t\t\t\t\t\"selectedval\"    : 0,\n" +
              "\t\t\t\t\t\t\"impactonstatus\" : \"orange\"\n" +
              "\t\t\t\t\t},\n" +
              "\t\t\t\t\t{ \t\n" +
              "\t\t\t\t\t\t\"viewtype\"\t\t: 101,\n" +
              "\t\t\t\t\t\t\"questionstr\" \t: \"Shortness of breath\",\n" +
              "\t\t\t\t\t\t\"editboxans\"\t\t: \"\",\n" +
              "\t\t\t\t\t\t\"checkboxans\"\t: false,\n" +
              "\t\t\t\t\t\t\"haschildren\"\t\t: false,\n" +
              "\t\t\t\t\t\t\"children\"\t\t: [],\t\t\t\n" +
              "\t\t\t\t\t\t\"spinnerstr\"     : [],\t\n" +
              "\t\t\t\t\t\t\"selectedval\"    : 0,\n" +
              "\t\t\t\t\t\t\"impactonstatus\" : \"orange\"\n" +
              "\t\t\t\t\t},\n" +
              "\t\t\t\t\t{ \t\n" +
              "\t\t\t\t\t\t\"viewtype\"\t\t: 101,\n" +
              "\t\t\t\t\t\t\"questionstr\" \t: \"None of the above\",\n" +
              "\t\t\t\t\t\t\"editboxans\"\t\t: \"\",\n" +
              "\t\t\t\t\t\t\"checkboxans\"\t: false,\n" +
              "\t\t\t\t\t\t\"haschildren\"\t\t: false,\n" +
              "\t\t\t\t\t\t\"children\"\t\t: [],\t\t\t\n" +
              "\t\t\t\t\t\t\"spinnerstr\"     : [],\t\n" +
              "\t\t\t\t\t\t\"selectedval\"    : 0,\n" +
              "\t\t\t\t\t\t\"impactonstatus\" : \"green\"\n" +
              "\t\t\t\t\t}\n" +
              "\t\t\t\t\n" +
              "\t\t\t\t],\t\t\t\n" +
              "\t\t\t\t\"spinnerstr\"     : [],\t\n" +
              "\t\t\t\t\"selectedval\"    : 0,\n" +
              "\t\t\t\t\"impactonstatus\" : \"none\"\n" +
              "\t\t},\n" +
              "\t\t{ \t\n" +
              "\t\t\t\"viewtype\"\t\t: 101,\n" +
              "\t\t\t\"questionstr\" \t: \"Do any of your co-living family members or room mates have any of the COVID-19 symptoms mentioned above ?\",\n" +
              "\t\t\t\"editboxans\"\t\t: \"\",\n" +
              "\t\t\t\"checkboxans\"\t: false,\n" +
              "\t\t\t\"haschildren\"\t\t: false,\n" +
              "\t\t\t\"children\"\t\t: [],\t\t\t\n" +
              "\t\t\t\"spinnerstr\"     : [],\t\n" +
              "\t\t\t\"selectedval\"    : 0,\n" +
              "\t\t\t\"impactonstatus\" : \"orange\"\n" +
              "\t\t},\n" +
              "\t\t{ \t\n" +
              "\t\t\t\"viewtype\"\t\t: 101,\n" +
              "\t\t\t\"questionstr\" \t: \"Did you visit any crowded place or area of mass gathering (Funeral/ Wedding/Birthday etc) in last 5 days ?\",\n" +
              "\t\t\t\"editboxans\"\t\t: \"\",\n" +
              "\t\t\t\"checkboxans\"\t: false,\n" +
              "\t\t\t\"haschildren\"\t\t: true,\n" +
              "\t\t\t\"children\"\t\t: [\n" +
              "\t\t\t\t{ \t\n" +
              "\t\t\t\t\t\"viewtype\"\t\t: 102,\n" +
              "\t\t\t\t\t\"questionstr\" \t: \"Please mention the details of crowded place visited or event attended\",\n" +
              "\t\t\t\t\t\"editboxans\"\t\t: \"\",\n" +
              "\t\t\t\t\t\"checkboxans\"\t: false,\n" +
              "\t\t\t\t\t\"haschildren\"\t\t: false,\n" +
              "\t\t\t\t\t\"children\"\t\t: [],\t\t\t\n" +
              "\t\t\t\t\t\"spinnerstr\"     : [],\t\n" +
              "\t\t\t\t\t\"selectedval\"    : 0,\n" +
              "\t\t\t\t\t\"impactonstatus\" : \"none\"\t\t\t\t\t\n" +
              "\t\t\t\t}\n" +
              "\t\t\t],\t\t\t\n" +
              "\t\t\t\"spinnerstr\"     : [],\t\n" +
              "\t\t\t\"selectedval\"    : 0,\n" +
              "\t\t\t\"impactonstatus\" : \"orange\"\t\t\t\n" +
              "\t\t},\n" +
              "\t\t{ \t\n" +
              "\t\t\t\t\"viewtype\"\t\t: 101,\n" +
              "\t\t\t\t\"questionstr\" \t: \"Did you visit any place outside Delhi/NCR in last 5 days ?\",\n" +
              "\t\t\t\t\"editboxans\"\t\t: \"\",\n" +
              "\t\t\t\t\"checkboxans\"\t: false,\n" +
              "\t\t\t\t\"haschildren\"\t\t: true,\n" +
              "\t\t\t\t\"children\"\t\t: [\n" +
              "\t\t\t\t\t{ \t\n" +
              "\t\t\t\t\t\t\"viewtype\"\t\t: 102,\n" +
              "\t\t\t\t\t\t\"questionstr\" \t: \"Please mention the details of place visited outside Delhi/NCR\",\n" +
              "\t\t\t\t\t\t\"editboxans\"\t\t: \"\",\n" +
              "\t\t\t\t\t\t\"checkboxans\"\t: false,\n" +
              "\t\t\t\t\t\t\"haschildren\"\t\t: false,\n" +
              "\t\t\t\t\t\t\"children\"\t\t: [],\t\t\t\n" +
              "\t\t\t\t\t\t\"spinnerstr\"     : [],\t\n" +
              "\t\t\t\t\t\t\"selectedval\"    : 0,\n" +
              "\t\t\t\t\t\t\"impactonstatus\" : \"none\"\n" +
              "\t\t\t\t\t}\n" +
              "\t\t\t\t\t\n" +
              "\t\t\t\t],\t\t\t\n" +
              "\t\t\t\t\"spinnerstr\"     : [],\t\n" +
              "\t\t\t\t\"selectedval\"    : 0,\n" +
              "\t\t\t\t\"impactonstatus\" : \"none\"\n" +
              "\t\t},\n" +
              "\t\t{ \t\n" +
              "\t\t\t\"viewtype\"\t\t: 101,\n" +
              "\t\t\t\"questionstr\" \t: \"Did you receive any communication / Guide from any Government health Official ?\",\n" +
              "\t\t\t\"editboxans\"\t\t: \"\",\n" +
              "\t\t\t\"checkboxans\"\t: false,\n" +
              "\t\t\t\"haschildren\"\t\t: true,\n" +
              "\t\t\t\"children\"\t\t: [\n" +
              "\t\t\t\t{ \t\n" +
              "\t\t\t\t\t\"viewtype\"\t\t: 102,\n" +
              "\t\t\t\t\t\"questionstr\" \t: \"Please share details on Govt Notice / Communication\",\n" +
              "\t\t\t\t\t\"editboxans\"\t\t: \"\",\n" +
              "\t\t\t\t\t\"checkboxans\"\t: false,\n" +
              "\t\t\t\t\t\"haschildren\"\t\t: true,\n" +
              "\t\t\t\t\t\"children\"\t\t: [],\t\t\t\n" +
              "\t\t\t\t\t\"spinnerstr\"     : [],\n" +
              "\t\t\t\t\t\"selectedval\"    : 0,\n" +
              "\t\t\t\t\t\"impactonstatus\" : \"none\"\n" +
              "\t\t\t\t}\n" +
              "\t\t\t],\t\t\t\n" +
              "\t\t\t\"spinnerstr\"     : [],\t\n" +
              "\t\t\t\"selectedval\"    : 0,\n" +
              "\t\t\t\"impactonstatus\" : \"none\"\n" +
              "\t\t},\n" +
              "\t\t{ \t\n" +
              "\t\t\t\"viewtype\"\t\t: 101,\n" +
              "\t\t\t\"questionstr\" \t: \"Any other information you would like to disclose / declare ?\",\n" +
              "\t\t\t\"editboxans\"\t\t: \"\",\n" +
              "\t\t\t\"checkboxans\"\t: false,\n" +
              "\t\t\t\"haschildren\"\t\t: true,\n" +
              "\t\t\t\"children\"\t\t: [\n" +
              "\t\t\t\t{ \t\n" +
              "\t\t\t\t\t\"viewtype\"\t\t: 102,\n" +
              "\t\t\t\t\t\"questionstr\" \t: \"Please share details\",\n" +
              "\t\t\t\t\t\"editboxans\"\t\t: \"\",\n" +
              "\t\t\t\t\t\"checkboxans\"\t: false,\n" +
              "\t\t\t\t\t\"haschildren\"\t\t: false,\n" +
              "\t\t\t\t\t\"children\"\t\t: [],\t\t\t\n" +
              "\t\t\t\t\t\"spinnerstr\"     : [],\t\n" +
              "\t\t\t\t\t\"selectedval\"    : 0,\n" +
              "\t\t\t\t\t\"impactonstatus\" : \"none\"\n" +
              "\t\t\t\t}\n" +
              "\t\t\t],\t\t\t\t\t\n" +
              "\t\t\t\"spinnerstr\"     : [],\t\n" +
              "\t\t\t\"selectedval\"    : 0,\n" +
              "\t\t\t\"impactonstatus\" : \"none\"\n" +
              "\t\t},\n" +
              "\t\t{ \t\n" +
              "\t\t\t\"viewtype\"\t\t: 103,\n" +
              "\t\t\t\"questionstr\" \t: \"Food Preference during office working for today\",\n" +
              "\t\t\t\"editboxans\"\t\t: \"\",\n" +
              "\t\t\t\"checkboxans\"\t: false,\n" +
              "\t\t\t\"haschildren\"\t\t: false,\n" +
              "\t\t\t\"children\"\t\t: [],\t\t\t\n" +
              "\t\t\t\"spinnerstr\"     : [\"I would bring my own food\",\"Avail Dry Lunch box at office\",\"I will not Join office today\"],\t\n" +
              "\t\t\t\"selectedval\"    : 0,\n" +
              "\t\t\t\"impactonstatus\" : \"none\"\n" +
              "\t\t}\n" +
              "\t]\n" +
              "}"
        val questionnaireResponse  =  gson.fromJson(jsonStr,QuestionnaireResponse::class.java)
        testingArrayList.addAll(questionnaireResponse.questions)

    }
}*/